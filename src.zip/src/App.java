public class App {
    public static void main(String[] args) throws Exception {
        Login l = new Login();
    }
}